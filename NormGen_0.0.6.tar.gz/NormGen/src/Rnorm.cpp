// [[Rcpp::depends(RcppParallel)]]
#include <RcppParallel.h>
#include <Rcpp.h>
#include <algorithm>
#include <cmath>
#include <random>

using namespace RcppParallel;

// --- COEFFICIENT TABLES FOR THE NORMAL GENERATOR ALGORITHM ---
const double TGP[33] = {
    3.16712418331199E-05, 8.84172852008038E-05, 2.32629079035525E-04, 5.770250421390766E-04,
    1.34989803163009E-03, 2.97976323505456E-03, 6.20966532577613E-03, 1.22244726550447E-02,
    2.27501319481792E-02, 4.00591568638171E-02, 6.68072012688581E-02, 0.105649773666855,
    0.158655253931457,    0.226627352376868,    0.308537538725987,    0.401293674317076,
    0.5,                  0.598706325682924,    0.691462461274013,    0.773372647623132,
    0.841344746068543,    0.894350226333145,    0.933192798731142,    0.959940843136183,
    0.977249868051821,    0.987775527344955,    0.993790334674224,    0.997020236764945,
    0.99865010196837,     0.999422974957609,    0.999767370920964,    0.999911582714799,
    0.999968328758167
};

const double A[128] = {
    464914109065.137, -124595326.266275, 13965.31021279, -4.33209076,
    24757302830.248, -17782555.5642977, 5400.05089066, -4.1055532,
    1575910993.9699, -2862023.37702872, 2221.62422704, -3.88177149,
    119773474.904744, -519054.52241247, 972.21829113, -3.66118248,
    10854124.544339, -105977.03925323, 452.4199185, -3.44430595,
    1170890.75455643, -24331.50724401, 223.78318641, -3.23176032,
    150056.93955952, -6272.70379607, 117.59481778, -3.02427964,
    22790.84185251, -1812.46344529, 65.60171626, -2.82273021,
    4090.3681954, -585.58561135, 38.81477955, -2.62812376,
    864.53027872, -210.91756019, 24.32686226, -2.44162237,
    214.39285477, -84.37162261, 16.12358665, -2.26453048,
    62.18862742, -37.31655958, 11.27752666, -2.09828129,
    21.10616563, -18.17071165, 8.30466821, -1.94448472,
    8.47751337, -9.73754331, 6.42811609, -1.80534175,
    4.19588751, -5.83773546, 5.24441528, -1.68561226,
    2.8014127, -4.1904022, 4.59597095, -1.60056151,
    2.8014127, -4.21383589, 4.61940464, -1.60641994,
    4.19588751, -6.74992707, 6.15660689, -1.91695507,
    8.47751337, -15.6949968, 12.38556958, -3.3627444,
    21.10616563, -45.14778525, 35.28174181, -9.29563748,
    62.18862742, -149.2493227, 123.21028978, -34.05131322,
    214.39285477, -558.80694169, 490.55890573, -143.88028833,
    864.53027875, -2382.67327604, 2196.08257811, -675.49795845,
    4090.36819533, -11685.51897466, 11138.74814286, -3540.96923978,
    22790.84185839, -66560.06212955, 64813.20040022, -21041.15739884,
    150056.9398155, -443898.11564334, 437743.00665802, -143898.80655053,
    1170890.74030507, -3488340.71386764, 3464232.9900057, -1146779.78468281,
    10854124.8776582, -32456397.5915553, 32350872.9700587, -10748596.8118556,
    119773481.246896, -358801389.199922, 358283306.877463, -119255395.263254,
    1575877457.23404, -4724770389.05577, 4721910628.02015, -1573017692.31665,
    24752920061.7601, -74240979740.263, 74223204695.0259, -24735145012.4176,
    466663187395.837, -1399864651796.75, 1399739755385.99, -466538290980.746
};

// --- WORKER STRUCTURE FOR MULTITHREADED COMPUTATION ---
struct ParallelRnormWorker : public Worker {
    RVector<double> output;
    double mean;
    double sd;
    unsigned int base_seed;

    ParallelRnormWorker(Rcpp::NumericVector output, double mean, double sd, unsigned int seed)
        : output(output), mean(mean), sd(sd), base_seed(seed) {}

    void operator()(std::size_t begin, std::size_t end) {
        // Unique engine instance per thread to prevent data races
        std::mt19937 engine(base_seed + begin);
        std::uniform_real_distribution<double> dist(0.0, 1.0);

        for (std::size_t i = begin; i < end; ++i) {
            double ip = dist(engine);
            int np = -1;

            if (ip < TGP[0])       np = 0;
            else if (ip > TGP[32]) np = 33;
            else {
                auto it = std::lower_bound(TGP, TGP + 33, ip);
                np = std::distance(TGP, it);
            }

            if (np > 0 && np < 33) {
                int idx = (np - 1) * 4;
                double val = A[idx+3] + ip * (A[idx+2] + ip * (A[idx+1] + A[idx] * ip));
                output[i] = val * sd + mean;
            } else {
                double q = ip;
                double p_val = std::min(q, 1.0 - q);
                if (p_val < 1e-16) p_val = 1e-16;

                double x_val = -std::sqrt(-std::log(-4.0 * M_PI * p_val * p_val * std::log(p_val)))
                               - 4.67143488752887E-02 * std::pow(p_val, 9.72914845210256E-02)
                               - 0.10862894518844 * std::pow(p_val, 0.409318862130021);
                output[i] = ((q <= 0.5) ? x_val : -x_val) * sd + mean;
            }
        }
    }
};

//' @title Parallel Pseudo-Normal Random Number Generator
//' @description Generates pseudo-random numbers from a normal distribution using multiple threads.
//' @param n number of samples
//' @param mean distribution mean
//' @param sd distribution standard deviation
//' @param seed generator seed
//' @export
// [[Rcpp::export]]
Rcpp::NumericVector parallel_Rnorm(long long n, double mean = 0.0, double sd = 1.0, unsigned int seed = 12345) {
    Rcpp::NumericVector out(n);
    ParallelRnormWorker worker(out, mean, sd, seed);
    parallelFor(0, n, worker, 1000);
    return out;
}

//' @title Single-threaded Pseudo-Normal Random Number Generator
//' @description Original single-threaded implementation of the NormGen quantile mapping algorithm.
//' @param n number of samples
//' @param m distribution mean
//' @param s distribution standard deviation
//' @export
// [[Rcpp::export]]
Rcpp::NumericVector Rnorm(int n, double m = 0.0, double s = 1.0) {
    Rcpp::NumericVector R(n);
    double* out = R.begin();
    Rcpp::RNGScope rngScope;

    for (int i = 0; i < n; ++i) {
        double ip = ::unif_rand();
        int np = -1;

        if (ip < TGP[0])       np = 0;
        else if (ip > TGP[32]) np = 33;
        else {
            auto it = std::lower_bound(TGP, TGP + 33, ip);
            np = std::distance(TGP, it);
        }

        if (np > 0 && np < 33) {
            int idx = (np - 1) * 4;
            double val = A[idx+3] + ip * (A[idx+2] + ip * (A[idx+1] + A[idx] * ip));
            out[i] = val * s + m;
        } else {
            double q = ip;
            double p_val = std::min(q, 1.0 - q);
            if (p_val < 1e-16) p_val = 1e-16;

            double x_val = -std::sqrt(-std::log(-4.0 * M_PI * p_val * p_val * std::log(p_val)))
                           - 4.67143488752887E-02 * std::pow(p_val, 9.72914845210256E-02)
                           - 0.10862894518844 * std::pow(p_val, 0.409318862130021);
            out[i] = (q <= 0.5) ? x_val : -x_val;
            out[i] = out[i] * s + m;
        }
    }
    return R;
}
